#define goal 318042
#define start  729630

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h> 
#include <cstring>
#include <climits>
#include <cfloat>
#include <math.h>
#include "Structures.cpp"
#include "Heuristic.cpp"
#include "BinarySearch.cpp"
#include "Queues.cpp"


node *nodes;
connection *conns;

AStarNode *astar;


unsigned int nodeIndex=0;
unsigned int connsCounter=0;

unsigned int* openListBase;
unsigned int* closedListBase;

QueueStar openList;
QueueStar closedList;

unsigned int CurrentNode;
bool flag_for_break=false;

int main(){
/*******************************************Reading the files***********************************************/
	std::FILE *Conns_infile;
	std::FILE *Nodes_infile;

	if((Nodes_infile=std::fopen("NodesCataluna.dat","r")) == NULL){ 
    	std::cerr << "The input binary data file cannot be opened.\n" << std::endl;
		return 1;
	}
	else{
		if (fread(&nodeIndex, sizeof(unsigned int), 1, Nodes_infile)!=1){
			std::cerr << "Impossible to read the size.\n" << std::endl;
			return 1;			
		}
		if((nodes = (node*)malloc(nodeIndex*(sizeof(node))))==NULL){
			std::cerr << "Cannot allocate enough memory.\n" << std::endl;
			return 1;
		}
		else if (fread(nodes, sizeof(node), nodeIndex, Nodes_infile)!=nodeIndex){
			std::cerr << "Impossible to read the nodes.\n" << std::endl;
			free(nodes);
			std::fclose(Nodes_infile);
			return 1;			
		}
		std::fclose(Nodes_infile);
	}

	if((Conns_infile=std::fopen("ConnectionsCataluna.dat","r")) == NULL){ 
    	std::cerr << "The input binary data file cannot be opened.\n" << std::endl;
		return 1;
	}
	else{
		if (fread(&connsCounter, sizeof(unsigned int), 1, Conns_infile)!=1){
			std::cerr << "Impossible to read the size.\n" << std::endl;
			return 1;			
		}
		if((conns = (connection*)malloc(connsCounter*(sizeof(connection))))==NULL){
			std::cerr << "Cannot allocate enough memory.\n" << std::endl;
			return 1;
		}
		else if (fread(conns, sizeof(connection), connsCounter, Conns_infile)!=connsCounter){
			std::cerr << "Impossible to read the nodes.\n" << std::endl;
			free(nodes);
			free(conns);
			std::fclose(Conns_infile);
			return 1;			
		}
		std::fclose(Conns_infile);
	}

	printf("%u\n", nodeIndex);
	printf("%u\n", connsCounter);
/*******************************************Reading the files***********************************************/
/****************************************Constructing A* First Conditions***********************************/
	if((astar = (AStarNode*)malloc(nodeIndex*(sizeof(AStarNode))))==NULL){
			std::cerr << "Cannot allocate enough memory.\n" << std::endl;
			free(nodes);
			free(conns);
			return 1;
	}

	for (int counter=0; counter<nodeIndex; counter++){
		(astar+counter)->whq=NONE;
		(astar+counter)->PosInQueue=0;
	}
	if((openListBase = (unsigned int *)malloc(nodeIndex*(sizeof(unsigned int))))==NULL){
			std::cerr << "Cannot allocate enough memory.\n" << std::endl;
			free(nodes);
			free(conns);
			return 1;
	}
	if((closedListBase = (unsigned int *)malloc(nodeIndex*(sizeof(unsigned int))))==NULL){
			std::cerr << "Cannot allocate enough memory.\n" << std::endl;
			free(nodes);
			free(conns);
			free(openListBase);
			return 1;
	}

	printf("%u\n", binarySearch(nodes, 0, nodeIndex-1,  771979683));
	printf("%u\n", binarySearch(nodes, 0, nodeIndex-1,  429854583));
/****************************************Constructing A* First Conditions***********************************/
/***********************************************Initializing Queues*****************************************/
	openList.base=openListBase;
	openList.QSize=0;
	openList.MaxQSize=nodeIndex;
	openList.whq=OPEN;

	closedList.base=closedListBase;
	closedList.QSize=0;
	closedList.MaxQSize=nodeIndex;
	closedList.whq=CLOSED;
/***********************************************Initializing Queues*****************************************/
/***********************************************  A Estrella       *****************************************/
	double goalLat=(nodes+goal)->lat;
	double goalLon=(nodes+goal)->lon;
	//Setting start node in OpenList

	(astar+start)->g=0.0;
	(astar+start)->h=HarvesineD((nodes+start)->lat, (nodes+start)->lon, goalLat, goalLon);

	printf("Heuristic %f\n", (astar+start)->f);
	(astar+start)->f=(astar+start)->h;
	//Push after updating since updates the minimum
	push2Queue(&openList, astar, start);
	
/**********************************************************************************DEBUGGING OF EXTRACTION**********************************************************************************************
	(astar+start+2)->f=(astar+start)->h+1;
	(astar+start+3)->f=(astar+start)->h-1;
	(astar+start+90)->f=(astar+start)->h-10;
	(astar+start+50)->f=(astar+start)->h+8;

	push2Queue(&openList, astar, start+2);
	push2Queue(&openList, astar, start+3);
	push2Queue(&openList, astar, start+90);
	push2Queue(&openList, astar, start+50);
********
	for (int counter=0; counter<openList.QSize; counter++){
		printf("%d, %f, %u, %f, %u, %u\n", counter, openList.MinF, openList.PointsMinF, (astar+*(openList.base+counter))->f,(astar+*(openList.base+counter))->PosInQueue, *(openList.base+counter));
	}


	extract4Open(&openList, astar, 2);	
	for (int counter=0; counter<openList.QSize; counter++){
		printf("%d, %f, %u, %f, %u, %u\n", counter, openList.MinF, openList.PointsMinF, (astar+*(openList.base+counter))->f,(astar+*(openList.base+counter))->PosInQueue, *(openList.base+counter));
	}

	printf("%u\n", ExtractMinimum(&openList));
*******************************************************************************************************************************************************************************************************/	
	//Pushing to OpenList the startNode 

//	printf("Error=%hu\n", extract4Open(&openList, astar, start));

	//Pushing to OpenList the startNode 
//	push2Queue(&openList, astar, start);
	/*****************************************SUPER WHILE****************************************************/
	double current_succesor_cost=DBL_MAX;	
	unsigned int NodeSuccesor=CurrentNode;

	while (!flag_for_break){
		//printf("%u\n", CurrentNode);
		if((CurrentNode==goal) || (openList.QSize==0)){
			flag_for_break=true;
		}
		else{
			CurrentNode=ExtractMinimum(&openList);
			extract4Open(&openList, astar, CurrentNode);
			for(unsigned int nnsuc=nodes[CurrentNode].offset; nnsuc<(nodes[CurrentNode].offset+nodes[CurrentNode].nsucc); nnsuc++){
				
				NodeSuccesor=conns[nnsuc].destination;
				//printf("%u, %u\n", nnsuc, CurrentNode);
				current_succesor_cost=(astar+CurrentNode)->g+PitagorasD((nodes+CurrentNode)->lat, (nodes+CurrentNode)->lon, (nodes+NodeSuccesor)->lat, (nodes+NodeSuccesor)->lon);
				if((astar+NodeSuccesor)->whq==NONE){

					(astar+NodeSuccesor)->h=HarvesineD( (nodes+NodeSuccesor)->lat, (nodes+NodeSuccesor)->lon,  goalLat,  goalLon);
					(astar+NodeSuccesor)->g=current_succesor_cost;
					(astar+NodeSuccesor)->f=(astar+NodeSuccesor)->h+(astar+NodeSuccesor)->g;
					(astar+NodeSuccesor)->parent=CurrentNode;
					push2Queue(&openList, astar, NodeSuccesor);

				}
				else if ((astar+NodeSuccesor)->g>current_succesor_cost){
					
					if((astar+NodeSuccesor)->whq==CLOSED){

						extract4Closed(&closedList, astar , NodeSuccesor);

						(astar+NodeSuccesor)->g=current_succesor_cost;
						(astar+NodeSuccesor)->f=(astar+NodeSuccesor)->h+(astar+NodeSuccesor)->g;
						(astar+NodeSuccesor)->parent=CurrentNode;
										
						push2Queue(&openList, astar, NodeSuccesor);

					}else if ((astar+NodeSuccesor)->whq==OPEN){

						extract4Open(&openList, astar , NodeSuccesor);
						(astar+NodeSuccesor)->g=current_succesor_cost;
						(astar+NodeSuccesor)->f=(astar+NodeSuccesor)->h+(astar+NodeSuccesor)->g;
						(astar+NodeSuccesor)->parent=CurrentNode;
						push2Queue(&openList, astar, NodeSuccesor);
					}
				}
				//printf("CurrentNODE:%u", nodes[CurrentNode].nsucc);
			}
			
			push2Queue(&closedList, astar, CurrentNode);
			
		}
	}

	if(CurrentNode!=goal){
		printf("Pisamos");
	}
	else{
		printf("Latitude, Longitude, Name, Icon, IconHeading, IconColor, LineColor\n");
		printf("%f\n", astar[astar[goal].parent].g);
		unsigned int traveler=goal;
		unsigned int travelerDad=0;
		double j=0;
		while(traveler!=start){

			travelerDad=astar[traveler].parent;
			j=j+PitagorasD(nodes[traveler].lat, nodes[traveler].lon, nodes[travelerDad].lat, nodes[travelerDad].lon);
			traveler=travelerDad;
			
//			printf("%u, LAT: %f, LONG: %f\n ", nodes[traveler].id, nodes[traveler].lat, nodes[traveler].lon);
//			printf("%f, %f, %d,, line-180, yellow, aqua\n", nodes[traveler].lat, nodes[traveler].lon, j);
		}
		printf("%f\n", j);
	}
	/*****************************************SUPER WHILE****************************************************/
	

/*	printf("%f\n", HarvesineD(41.231982, 1.690731, 41.232422, 1.690718));
	printf("%f, %f\n", (nodes)->lat, (nodes)->lon);
	printf("%f, %f\n", (nodes+1)->lat, (nodes+1)->lon);
*/


/***********************************************  A Estrella       *****************************************/
	free(astar);
	free(nodes);
	free(conns);
	free(openListBase);
	free(closedListBase);
	return 0;
}
