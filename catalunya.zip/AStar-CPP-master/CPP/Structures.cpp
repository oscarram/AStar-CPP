typedef struct {
	unsigned int id;          // Node identification
	char name='a';
	double lat, lon;           // Node position
	unsigned short nsucc=0;      // Number of node successors; i. e. length of successors
	unsigned int offset;
} node;

typedef struct {
	unsigned int source;
	unsigned int destination;
 	double weight;
} connection;


typedef char Queue;
enum whichQueue {NONE, OPEN, CLOSED};

typedef struct {
	double g, h, f;
	unsigned int parent; //Vector Position
	unsigned int PosInQueue;
	Queue whq;
} AStarNode;

void set_Maximum_node_Descendant_N(unsigned short comp, unsigned short *counter){
	if(comp> (*counter)){
		(*counter)=comp;					
	}
}
